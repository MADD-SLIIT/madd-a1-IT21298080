package com.example.maddfinal.Helper

interface ChangeNumberItemsListener {
    fun onChanged() // Function name changed to follow Kotlin conventions
}