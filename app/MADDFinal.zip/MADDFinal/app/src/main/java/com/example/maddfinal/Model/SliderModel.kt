package com.example.maddfinal.Model

data class SliderModel(val url:String="")
